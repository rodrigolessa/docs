﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BuscaPeticoes
{
    class Peticao
    {

        private string processo;
        private string rpi;
        private string cod_desp;
        private string pgo;
        private string protocolo;
        private string data;
        private string img;
        private string servico;
        private string cliente;
        private string delivery;
        private string codProcesso_inpi;



        public string Processo
        {
            get { return processo; }
            set { processo = value; }
        }

        public string Rpi
        {
            get { return rpi; }
            set { rpi = value; }
        }

        public string Cod_desp
        {
            get { return cod_desp; }
            set { cod_desp = value; }
        }

        public string Pgo
        {
            get { return pgo; }
            set { pgo = value; }
        }

        public string Protocolo
        {
            get { return protocolo; }
            set { protocolo = value; }
        }

        public string Data
        {
            get { return data; }
            set { data = value; }
        }

        public string Img
        {
            get { return img; }
            set { img = value; }
        }

        public string Servico
        {
            get { return servico; }
            set { servico = value; }
        }

        public string Cliente
        {
            get { return cliente; }
            set { cliente = value; }
        }

        public string Delivery
        {
            get { return delivery; }
            set { delivery = value; }
        }

        public string CodProcesso_inpi
        {
            get { return codProcesso_inpi; }
            set { codProcesso_inpi = value; }
        }

        public Peticao()
        {

            processo = "";
            rpi = "";
            cod_desp = "";
            pgo = "";
            protocolo = "";
            data = "";
            img = "";
            servico = "";
            cliente = "";
            delivery = "";
            codProcesso_inpi = "";
        }

        public Peticao(string Processo, string Rpi, string Cod_desp, string Pgo, string Protocolo, string Data,
            string Img, string Servico, string Cliente, string Delivery, string CodProcesso_inpi)
        {

            processo = Processo;
            rpi = Rpi;
            cod_desp = Cod_desp;
            pgo = Pgo;
            protocolo = Protocolo;
            data = Data;
            img = Img;
            servico = Servico;
            cliente = Cliente;
            delivery = Delivery;
            codProcesso_inpi = CodProcesso_inpi;

        }

    }
}
