﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BuscaPeticoes
{
    class Processo
    {
        private string processoNum;
        private string rpi;
        private string cod_desp;

        public string ProcessoNum
        {
            get { return processoNum; }
            set { processoNum = value; }
        }

        public string Rpi
        {
            get { return rpi; }
            set { rpi = value; }
        }

        public string Cod_desp
        {
            get { return cod_desp; }
            set { cod_desp = value; }
        }

        public Processo()
        {

            processoNum = "";
            rpi = "";
            cod_desp = "";

        }

        public Processo(string Processo, string Rpi, string Cod_desp)
        {

            processoNum = Processo;
            rpi = Rpi;
            cod_desp = Cod_desp;

        }
    }
}
