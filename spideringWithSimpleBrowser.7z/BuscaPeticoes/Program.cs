﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Configuration;
using HtmlAgilityPack;

using SimpleBrowser;

using System.Data;
using System.Data.SqlClient;

namespace BuscaPeticoes
{
    class Program
    {
        static void Main(string[] args)
        {
            string rpi = "2250";
            string despacho = "I009";

            //("907060285","2250","I009");
            Console.WriteLine("" + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " - INI - Obtendo processos, RPI:" + rpi + ", Despacho:" + despacho + ". ");
            List<Processo> Processos = ObterProcessosPorDespachoRpi("2250", "I009");
            Console.WriteLine("" + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " - FIM - Obtendo processos, RPI:" + rpi + ", Despacho:" + despacho + ". ");
            Console.WriteLine("" + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " QTD Processos:" + Processos.Count);
            Console.WriteLine("");
            Console.WriteLine("");


            foreach (Processo processo in Processos)
            {
                Console.WriteLine(" " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " - INI - Processo " + processo.ProcessoNum + ", obtendo Peticoes...");
                List<Peticao> Peticoes = BuscaPeticao(processo);
                Console.WriteLine(" " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " - FIM - Processo " + processo.ProcessoNum + ", obtendo Peticoes...");
                Console.WriteLine(" " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " Processo " + processo.ProcessoNum + ", QTD peticoes: " + Peticoes.Count + " ");

                Console.WriteLine(" " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " - INI - Processo " + processo.ProcessoNum + ", gravando Peticoes...");
                Console.WriteLine("");
                GravaPeticao(Peticoes);
                Console.WriteLine("");
                Console.WriteLine(" " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " - FIM - Processo " + processo.ProcessoNum + ", gravando Peticoes...");

                Console.WriteLine(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " Sleep...");
                Console.WriteLine("");

                System.Threading.Thread.Sleep(1000 * 10);

            }
            //List<Peticao> Peticoes = BuscaPeticao(new Processo("902033298", "2250", "I009"));
            //GravaPeticao(Peticoes);

        }

        private static void GravaPeticao(List<Peticao> Peticoes)
        {
            SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings.Get("SqlStringConn"));
            SqlCommand command = new SqlCommand();
            command.Connection = conn;

            conn.Open();
            foreach (Peticao peticao in Peticoes)
            {
                command.CommandText = "exec [PR_GRAVA_PETICAO] '" + peticao.Processo + "', '" + peticao.Rpi + "', '" + peticao.Cod_desp + "' "
                    + ", '" + peticao.Pgo + "', '" + peticao.Protocolo + "', '" + trataData(peticao.Data) + "', '" + peticao.Img + "', '" + peticao.Servico + "' "
                    + ", '" + trata(peticao.Cliente) + "', '" + peticao.Delivery + "', '" + peticao.CodProcesso_inpi + "' ";

                command.ExecuteNonQuery();

                Console.WriteLine("    " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " - Processo " + peticao.Processo + ", Protocolo:" + peticao.Protocolo + ",Servico:" + peticao.Servico + " ");



            }

            command.Dispose();

            conn.Close();

            conn.Dispose();


        }

        private static string trata(string p)
        {
            string retorno = "";

            retorno = p.Replace("'", "''");

            return retorno;
        }

        private static string trataData(string data)
        {
            string retorno = "";
            DateTime date = DateTime.Parse(data);

            retorno = date.ToString("yyyy-MM-dd");

            return retorno;
        }

        private static List<Processo> ObterProcessosPorDespachoRpi(string RPI, string DESPACHO)
        {
            List<Processo> retorno = new List<Processo>();

            SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings.Get("SqlStringConn"));
            SqlCommand command = new SqlCommand();
            command.Connection = conn;
            command.CommandText = "exec [PR_OBTEM_PROCESSOS_POR_DESPACHO_RPI] " + RPI + ", " + DESPACHO + " ";

            conn.Open();
            SqlDataReader dr = command.ExecuteReader();

            while (dr.Read())
            {
                retorno.Add(new Processo(dr["processo"].ToString(), RPI, DESPACHO));
            }

            dr.Close();
            dr.Dispose();

            command.Dispose();

            conn.Close();

            conn.Dispose();

            return retorno;
        }

        private static List<Peticao> BuscaPeticao(Processo processo)
        {
            List<Peticao> retorno = new List<Peticao>();

            var browser = new Browser();
            try
            {
                //TODO: Obter lista de procesos para consulta

                // log the browser request/response data to files so we can interrogate them in case of an issue with our scraping
                //browser.RequestLogged += OnBrowserRequestLogged;
                //browser.MessageLogged += new Action<Browser, string>(OnBrowserMessageLogged);

                // we'll fake the user agent for websites that alter their content for unrecognised browsers
                browser.UserAgent = "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/534.10";

                // browse to GitHub
                browser.Navigate("https://gru.inpi.gov.br/pPI/");

                //TODO: Navegar por URL para Pesquisa em Propriedade Industrial
                //https://gru.inpi.gov.br/pePI/

                //https://gru.inpi.gov.br/pPI/servlet/MarcasServletController?action=detail&codProcesso=2283880
                if (LastRequestFailed(browser)) return retorno; // always check the last request in case the page failed to load

                // click the login link and click it
                //browser.Log("First we need to log in, so browse to the login page, fill in the login details and submit the form.");
                //var loginLink = browser.Find("a", FindBy.Text, "Login");
                //if (!loginLink.Exists)

                //loginLink.Click();
                //if (LastRequestFailed(browser)) return;

                //TODO: Clicar no link de continuar
                //<a href="/pePI/servlet/LoginController?action=login" target="_blank"> Continuar.... </a>

                //TODO: Clicar no link de patentes para buscar processos
                //<area coords="251,16,482,72" href="/pePI/jsp/patentes/PatenteSearchBasico.jsp" shape="rect" data-mce-href="menu-servicos/patente">

                //TODO: Localizar número do processo: 102012003991
                //<input class="basic" name="NumPedido" size="30" maxlength="300" type="text">

                //TODO: Ativar busca
                //<input name="botao" class="basic" value=" pesquisar » " type="submit">

                //TODO: Clicar no primeiro processo encontrado
                //<a href="/pePI/servlet/PatenteServletController?Action=detail&amp;CodPedido=903184&amp;SearchParameter=102012003991" class="visitado"> BR 10 2012 003991 5 </a>

                //TODO: Clicar no icone para download do PDF de Publicações
                //<img id="c4bac120a852bb298e6322c80bc838e1dbd490307ff66e666936e127fa73e1cb" src="../jsp/imagens/iconePdf.png" alt="Imagem do Documento em PDF" class="salvaDocumento cursor" align="top" border="0" width="16" height="16">

                //TODO: Obter e interpretar código do CAPTCHA
                //<img src="captcha.jpg?23 &quot; />" id="captchaImg" style="margin-top: 5px">

                //TODO: Inserir código do Captcha
                //<input id="captchaInput" name="captcha" style="width: 85px; text-align: center; margin-bottom: 5px" maxlength="5" type="text">


                // fill in the form and click the login button - the fields are easy to locate because they have ID attributes
                browser.Find(ElementType.TextField, "name", "T_Login").Value = "testebga";
                browser.Find(ElementType.TextField, "name", "T_Senha").Value = "aaaaaaaq";
                browser.Find(ElementType.Button, "type", "submit").Click();
                if (LastRequestFailed(browser)) return retorno;

                // see if the login succeeded - ContainsText() is very forgiving, so don't worry about whitespace, casing, html tags separating the text, etc.
                if (browser.ContainsText("Incorrect login or password"))
                {
                    browser.Log("Login failed!", LogMessageType.Error);
                }
                else
                {
                    browser.Navigate("https://gru.inpi.gov.br/pPI/jsp/marcas/Pesquisa_num_processo.jsp");
                    if (LastRequestFailed(browser)) return retorno;

                    browser.Find(ElementType.TextField, "name", "numProcesso").Value = processo.ProcessoNum;

                    browser.Find(ElementType.Button, "type", "submit").Click();
                    if (LastRequestFailed(browser)) return retorno;


                    //browser.Log(browser.CurrentHtml.ToString());

                    var processoLink = browser.Find("a", FindBy.Text, processo.ProcessoNum);

                    processoLink.Click();
                    if (LastRequestFailed(browser)) return retorno;

                    browser.Log(browser.CurrentHtml.ToString());

                    string page = browser.CurrentHtml.ToString();

                    HtmlDocument doc = new HtmlDocument();
                    doc.LoadHtml(page);

                    string[] asdasd = "codProcesso=".Split(';');

                    String[] querystrings = browser.Url.Query.ToString().Split(asdasd, 3, System.StringSplitOptions.None);

                    String codProcessoINPI = querystrings[1];

                    int indiceInicialTr = 3;

                    int indiceFinalTr = (doc.DocumentNode.SelectSingleNode("//*[@id='principal']/table[3]/tbody[1]").ChildNodes.Count - 1) / 2;


                    for (int i = indiceInicialTr; i <= indiceFinalTr; i++)
                    {


                        //.ChildAttributes("tr");

                        String Protocolo = doc.DocumentNode.SelectSingleNode("//*[@id='principal']/table[3]/tbody[1]/tr[" + i + "]/td[2]/font").InnerText.ToString();
                        String Data = doc.DocumentNode.SelectSingleNode("//*[@id='principal']/table[3]/tbody[1]/tr[" + i + "]/td[3]/font").InnerText.ToString();
                        String Servico = doc.DocumentNode.SelectSingleNode("//*[@id='principal']/table[3]/tbody[1]/tr[" + i + "]/td[5]/font").InnerText.ToString();

                        //Servico = Servico.Replace(Environment.NewLine, "");
                        Servico = Servico.Replace("\n", "");
                        Servico = Servico.Replace("\r", "");
                        Servico = Servico.Replace(" ", "");
                        Servico = Servico.Trim();


                        String Cliente = doc.DocumentNode.SelectSingleNode("//*[@id='principal']/table[3]/tbody[1]/tr[" + i + "]/td[6]/font").InnerText.ToString();

                        retorno.Add(new Peticao(processo.ProcessoNum, processo.Rpi, processo.Cod_desp, "", Protocolo, Data, "", Servico, Cliente, "", codProcessoINPI));

                    }



                    //String asdaaaaaaaaaaaaaaaaasdasdasd = "";
                    //browser.Find(

                    // After logging in, we should check that the page contains elements that we recognise
                    //if (!browser.ContainsText("Your Repositories"))
                    //    browser.Log("There wasn't the usual login failure message, but the text we normally expect isn't present on the page");
                    //else
                    //{
                    //    browser.Log("Your News Feed:");
                    //    // we can use simple jquery selectors, though advanced selectors are yet to be implemented
                    //    foreach (var item in browser.Select("div.news .title"))
                    //        browser.Log("* " + item.Value);
                    //}

                }
            }
            catch (Exception ex)
            {
                browser.Log(ex.Message, LogMessageType.Error);
                browser.Log(ex.StackTrace, LogMessageType.StackTrace);
            }
            finally
            {
                //var path = WriteFile("log-" + DateTime.UtcNow.Ticks + ".html", browser.RenderHtmlLogFile("SimpleBrowser Sample - Request Log"));
                //Process.Start(path);

            }
            return retorno;
        }

        static bool LastRequestFailed(Browser browser)
        {
            if (browser.LastWebException != null)
            {
                browser.Log("There was an error loading the page: " + browser.LastWebException.Message);
                return true;
            }
            return false;
        }

        static void OnBrowserMessageLogged(Browser browser, string log)
        {
            Console.WriteLine(log);
            EscreveArquivo(log);
        }

        static void EscreveArquivo(string msg)
        {
            StreamWriter sr = new StreamWriter(@"./log_" + DateTime.Now.ToString("yyyyMMddHHmmssffff") + ".txt");
            sr.Write(msg);

            sr.Flush();
            sr.Close();


        }

        static void OnBrowserRequestLogged(Browser req, HttpRequestLog log)
        {
            Console.WriteLine(" -> " + log.Method + " request to " + log.Url);
            Console.WriteLine(" <- Response status code: " + log.StatusCode);
        }

        static string WriteFile(string filename, string text)
        {
            var dir = new DirectoryInfo(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs"));
            if (!dir.Exists) dir.Create();
            var path = Path.Combine(dir.FullName, filename);
            File.WriteAllText(path, text);
            return path;
        }
    }
}