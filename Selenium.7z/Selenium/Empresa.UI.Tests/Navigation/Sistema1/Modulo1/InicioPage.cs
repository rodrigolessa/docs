﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenQA.Selenium.Remote;

namespace LDSoft.APOL.UI.Tests.Navigation.APOL.Marcas
{
    public class InicioPage : MarcasInternoBase
    {
        public InicioPage(RemoteWebDriver driver)
            : base(driver)
        {
        }
    }
}
