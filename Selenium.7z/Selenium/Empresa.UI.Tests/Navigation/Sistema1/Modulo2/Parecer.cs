﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LDSoft.APOL.UI.Tests.Navigation.APOL.Patentes
{
    public class Parecer
    {
        public string NumeroProcesso { get; set; }
        public string RPI { get; set; }
        public string NumeroDespacho { get; set; }
        public string Arquivo { get; set; }
    }
}
