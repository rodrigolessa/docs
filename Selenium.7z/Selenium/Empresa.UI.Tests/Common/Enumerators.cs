﻿namespace LDSoft.APOL.UI.Tests.Common
{
    public enum Browsers
    {
        InternetExplorer,
        GoogleChrome,
        FireFox,
        //Opera,
        //Safari
    }

    public enum Modulos
    {
        Administrativo,
        Marcas,
        Patentes,
        Juridico,
        Contratos
    }

}
